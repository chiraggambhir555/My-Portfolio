# Healthcare Patient & Hospital Operations Analysis

A simple data analysis project using only **Python, NumPy, and Pandas**.

## Folder Structure
```
healthcare_analysis/
├── data/
│   └── patients_raw.csv        <- generated synthetic dataset (5000 rows)
├── src/
│   ├── generate_data.py        <- creates the fake dataset
│   └── analysis.py             <- cleans data + answers all questions
├── reports/
│   ├── patients_cleaned.csv    <- cleaned dataset with derived columns
│   └── summary_report.txt      <- key KPIs in plain text
└── README.md
```

## How to Run
1. Install requirements: `pip install numpy pandas`
2. Generate the dataset:
   ```
   cd src
   python generate_data.py
   ```
3. Run the analysis (answers all 16 questions, prints to console, saves reports):
   ```
   python analysis.py
   ```

## What Each Script Does

**generate_data.py**
Creates 5000 fake patient records (random ages, cities, bills, etc.) using
`numpy.random`, puts them into a pandas DataFrame, injects some missing
values on purpose, and saves it as `data/patients_raw.csv`.

**analysis.py**
Reads the CSV and works through 5 levels of questions:
- **Level 1 (Cleaning):** finds and fills missing values, fixes bad dates,
  adds new columns like `length_of_stay` and `age_group`.
- **Level 2 (Descriptive):** basic KPIs — total patients, avg bill,
  readmission rate, etc.
- **Level 3 (Business):** which city/department/treatment/doctor stands out.
- **Level 4 (Trend & Segmentation):** monthly trends and a 3-tier risk
  grouping built with `np.select`.
- **Level 5 (NumPy):** 95th percentile, correlation matrix, and z-score
  outlier detection.

## Key Concepts Used (so you can explain them in an interview)
- `np.random.choice` / `np.random.normal` — generating random sample data
- `groupby()` — splitting data into groups (e.g., by department) and
  summarizing each group
- `np.select()` — assigning a category based on multiple conditions,
  like an if/elif/else but vectorized (works on the whole column at once)
- `np.percentile()` — finds the value below which X% of data falls
- `np.corrcoef()` — measures how strongly two numeric columns move together
  (close to 1 = strong positive relationship, close to 0 = no relationship)
- **Z-score** — measures how many standard deviations a value is from the
  mean; a common rule of thumb is that |z| > 3 marks an outlier

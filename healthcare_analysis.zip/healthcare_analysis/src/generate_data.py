"""
generate_data.py
-----------------
This script creates a fake (synthetic) hospital dataset and saves it
as data/patients_raw.csv

We use only numpy and pandas, and keep the logic simple so it is easy
to explain in an interview:
- numpy is used to generate random numbers (ages, bills, choices, etc.)
- pandas is used to put everything into a table (DataFrame) and save it as CSV
"""

import numpy as np
import pandas as pd

# Setting a seed means we get the SAME random numbers every time we run
# the script. This makes our results reproducible.
np.random.seed(42)

# Number of patient records we want to create
n = 5000

# ---------------------------------------------------------
# 1. Generate patient IDs like PAT1001, PAT1002, ...
# ---------------------------------------------------------
patient_id = ["PAT" + str(i) for i in range(1001, 1001 + n)]

# ---------------------------------------------------------
# 2. Generate admission dates between 2022-01-01 and 2024-12-31
# ---------------------------------------------------------
admission_date = pd.date_range("2022-01-01", "2024-12-31", periods=n)

# ---------------------------------------------------------
# 3. Generate discharge dates = admission date + random days (1 to 30)
# ---------------------------------------------------------
stay_days = np.random.randint(1, 31, size=n)  # random number of days, 1 to 30
discharge_date = admission_date + pd.to_timedelta(stay_days, unit="D")

# ---------------------------------------------------------
# 4. Generate age, gender, city, department, doctor_id, diagnosis,
#    treatment_type, bed_type
# ---------------------------------------------------------
age = np.random.randint(1, 91, size=n)  # age between 1 and 90

gender = np.random.choice(["Male", "Female", "Other"], size=n, p=[0.49, 0.49, 0.02])

city = np.random.choice(["Delhi", "Mumbai", "Chennai", "Kolkata"], size=n)

department = np.random.choice(
    ["Cardiology", "Ortho", "Neurology", "Pediatrics", "General"], size=n
)

doctor_id = np.random.choice(
    ["DOC" + str(i).zfill(3) for i in range(1, 21)], size=n
)  # DOC001 to DOC020

diagnosis_list = [
    "Hypertension", "Diabetes", "Fracture", "Migraine", "Asthma",
    "Pneumonia", "Arthritis", "Appendicitis", "Anemia", "Bronchitis",
    "Kidney Stones", "Ulcer", "Cataract", "Dengue", "Typhoid",
]
diagnosis = np.random.choice(diagnosis_list, size=n)

treatment_type = np.random.choice(
    ["Surgery", "Medication", "Therapy", "Observation"], size=n
)

bed_type = np.random.choice(
    ["General", "Semi-Private", "Private", "ICU"], size=n, p=[0.4, 0.3, 0.2, 0.1]
)

# ---------------------------------------------------------
# 5. Generate bill_amount (different average ranges per department)
# ---------------------------------------------------------
# We first map each department to a base average cost, then add some
# random noise so not everyone in a department pays the exact same.
dept_base_cost = {
    "Cardiology": 80000,
    "Ortho": 60000,
    "Neurology": 90000,
    "Pediatrics": 30000,
    "General": 25000,
}

bill_amount = np.array([
    max(2000, np.random.normal(dept_base_cost[d], dept_base_cost[d] * 0.3))
    for d in department
])
bill_amount = np.round(bill_amount, 2)

# insurance_covered = a random % (0 to 90%) of the bill
insurance_pct = np.random.uniform(0, 0.9, size=n)
insurance_covered = np.round(bill_amount * insurance_pct, 2)

# out_of_pocket = bill - insurance covered
out_of_pocket = np.round(bill_amount - insurance_covered, 2)

# readmitted = 0 or 1 (about 15% chance of readmission)
readmitted = np.random.choice([0, 1], size=n, p=[0.85, 0.15])

# satisfaction_score between 1.0 and 5.0
satisfaction_score = np.round(np.random.uniform(1.0, 5.0, size=n), 1)

# ---------------------------------------------------------
# 6. Put everything into one DataFrame (table)
# ---------------------------------------------------------
df = pd.DataFrame({
    "patient_id": patient_id,
    "admission_date": admission_date,
    "discharge_date": discharge_date,
    "age": age,
    "gender": gender,
    "city": city,
    "department": department,
    "doctor_id": doctor_id,
    "diagnosis": diagnosis,
    "treatment_type": treatment_type,
    "bill_amount": bill_amount,
    "insurance_covered": insurance_covered,
    "out_of_pocket": out_of_pocket,
    "readmitted": readmitted,
    "satisfaction_score": satisfaction_score,
    "bed_type": bed_type,
})

# ---------------------------------------------------------
# 7. Inject some null (missing) values to make cleaning realistic
#    ~4% nulls in satisfaction_score, ~2% nulls in insurance_covered
# ---------------------------------------------------------
satisfaction_null_idx = np.random.choice(n, size=int(n * 0.04), replace=False)
df.loc[satisfaction_null_idx, "satisfaction_score"] = np.nan

insurance_null_idx = np.random.choice(n, size=int(n * 0.02), replace=False)
df.loc[insurance_null_idx, "insurance_covered"] = np.nan

# Also introduce a handful of "bad" rows where discharge is before
# admission, just so question 2 in the analysis has something to find.
bad_idx = np.random.choice(n, size=5, replace=False)
df.loc[bad_idx, "discharge_date"] = df.loc[bad_idx, "admission_date"] - pd.Timedelta(days=2)

# ---------------------------------------------------------
# 8. Save to CSV
# ---------------------------------------------------------
df.to_csv("data/patients_raw.csv", index=False)

print(f"Done! Generated {n} patient records -> data/patients_raw.csv")

"""
analysis.py
-----------
This script reads data/patients_raw.csv and answers all the questions
from Level 1 to Level 5. Only numpy and pandas are used, and the code
is kept simple and well-commented so each step is easy to explain.
"""

import numpy as np
import pandas as pd

pd.set_option("display.width", 120)

# ===========================================================
# Load the data
# ===========================================================
df = pd.read_csv("data/patients_raw.csv", parse_dates=["admission_date", "discharge_date"])

print("Data loaded. Shape:", df.shape)
print("\n" + "=" * 60)


# ===========================================================
# LEVEL 1 - DATA CLEANING
# ===========================================================
print("LEVEL 1 - DATA CLEANING")
print("=" * 60)

# Q1. How many nulls in each column, and how do we fill them?
print("\nQ1. Null counts per column:")
print(df.isnull().sum())

# satisfaction_score is a rating (1-5). The median is a safer choice
# than the mean because it is not affected by extreme/outlier ratings.
median_satisfaction = df["satisfaction_score"].median()
df["satisfaction_score"] = df["satisfaction_score"].fillna(median_satisfaction)

# insurance_covered is a money amount. We use the median of each
# department, since insurance coverage can vary a lot by department.
df["insurance_covered"] = df.groupby("department")["insurance_covered"] \
    .transform(lambda x: x.fillna(x.median()))

print("\nAfter filling -> remaining nulls:")
print(df.isnull().sum())

# Q2. Any patients where discharge_date is before admission_date?
bad_rows = df[df["discharge_date"] < df["admission_date"]]
print(f"\nQ2. Rows with discharge before admission: {len(bad_rows)}")
# Fix: swap the two dates for these rows (simple, safe fix)
swap_idx = bad_rows.index
df.loc[swap_idx, ["admission_date", "discharge_date"]] = \
    df.loc[swap_idx, ["discharge_date", "admission_date"]].values
print("Fixed by swapping admission/discharge dates for those rows.")

# Q3. Add derived columns
df["length_of_stay"] = (df["discharge_date"] - df["admission_date"]).dt.days

df["age_group"] = np.select(
    condlist=[df["age"] < 18, df["age"] <= 60],
    choicelist=["Child", "Adult"],
    default="Senior",
)

df["month"] = df["admission_date"].dt.month
df["quarter"] = df["admission_date"].dt.quarter
df["year"] = df["admission_date"].dt.year

print("\nQ3. Derived columns added: length_of_stay, age_group, month, quarter, year")
print(df[["length_of_stay", "age_group", "month", "quarter", "year"]].head())


# ===========================================================
# LEVEL 2 - DESCRIPTIVE ANALYSIS
# ===========================================================
print("\n" + "=" * 60)
print("LEVEL 2 - DESCRIPTIVE ANALYSIS")
print("=" * 60)

# Q4. Overall KPIs
total_patients = len(df)
avg_bill = df["bill_amount"].mean()
avg_los = df["length_of_stay"].mean()
readmission_rate = df["readmitted"].mean() * 100
avg_satisfaction = df["satisfaction_score"].mean()

print(f"\nQ4. Total patients: {total_patients}")
print(f"    Avg bill amount: {avg_bill:,.2f}")
print(f"    Avg length of stay: {avg_los:.2f} days")
print(f"    Readmission rate: {readmission_rate:.2f}%")
print(f"    Avg satisfaction score: {avg_satisfaction:.2f}")

# Q5. Department with highest avg bill, and most patients
dept_avg_bill = df.groupby("department")["bill_amount"].mean().sort_values(ascending=False)
dept_count = df["department"].value_counts()
print("\nQ5. Avg bill amount by department:")
print(dept_avg_bill)
print(f"\nDepartment with highest avg bill: {dept_avg_bill.idxmax()}")
print(f"Department with most patients: {dept_count.idxmax()} ({dept_count.max()} patients)")

# Q6. Distribution by age group and gender
age_gender_dist = df.groupby(["age_group", "gender"]).size().unstack(fill_value=0)
print("\nQ6. Patient count by age group and gender:")
print(age_gender_dist)
print("Pattern: compare row totals above to see which age group is largest overall.")


# ===========================================================
# LEVEL 3 - BUSINESS ANALYSIS
# ===========================================================
print("\n" + "=" * 60)
print("LEVEL 3 - BUSINESS ANALYSIS")
print("=" * 60)

# Q7. City with highest out-of-pocket cost; is insurance coverage consistent?
city_oop = df.groupby("city")["out_of_pocket"].mean().sort_values(ascending=False)
city_insurance = df.groupby("city")["insurance_covered"].mean()
print("\nQ7. Avg out-of-pocket cost by city:")
print(city_oop)
print(f"\nHighest out-of-pocket city: {city_oop.idxmax()}")
print("\nAvg insurance covered by city (consistency check):")
print(city_insurance)

# Q8. Treatment type with longest avg length of stay
treatment_los = df.groupby("treatment_type")["length_of_stay"].mean().sort_values(ascending=False)
print("\nQ8. Avg length of stay by treatment type:")
print(treatment_los)
print(f"Longest avg stay: {treatment_los.idxmax()}")

# Q9. Do ICU beds have higher readmission rate than General beds?
icu_rate = df[df["bed_type"] == "ICU"]["readmitted"].mean() * 100
general_rate = df[df["bed_type"] == "General"]["readmitted"].mean() * 100
print(f"\nQ9. ICU readmission rate: {icu_rate:.2f}%")
print(f"    General readmission rate: {general_rate:.2f}%")
print("ICU higher than General." if icu_rate > general_rate else "General is equal or higher than ICU.")

# Q10. Doctor with highest patient load and their avg satisfaction
doctor_load = df["doctor_id"].value_counts()
top_doctor = doctor_load.idxmax()
top_doctor_satisfaction = df[df["doctor_id"] == top_doctor]["satisfaction_score"].mean()
print(f"\nQ10. Doctor with highest patient load: {top_doctor} ({doctor_load.max()} patients)")
print(f"     Their avg satisfaction score: {top_doctor_satisfaction:.2f}")


# ===========================================================
# LEVEL 4 - TREND & SEGMENTATION
# ===========================================================
print("\n" + "=" * 60)
print("LEVEL 4 - TREND & SEGMENTATION")
print("=" * 60)

# Q11. Monthly admission trends (printed as a table)
monthly_trend = df.groupby(["year", "month"]).size().reset_index(name="admissions")
print("\nQ11. Monthly admission trends:")
print(monthly_trend.to_string(index=False))
busiest_month = monthly_trend.loc[monthly_trend["admissions"].idxmax()]
print(f"\nBusiest month: {int(busiest_month['month'])}/{int(busiest_month['year'])} "
      f"with {int(busiest_month['admissions'])} admissions")

# Q12. Segment patients into 3 risk groups using np.select
# Simple rule we define ourselves:
#  - High Risk: readmitted=1 AND length_of_stay > 15
#  - Medium Risk: readmitted=1 OR (age > 60 AND length_of_stay > 10)
#  - Low Risk: everyone else
conditions = [
    (df["readmitted"] == 1) & (df["length_of_stay"] > 15),
    (df["readmitted"] == 1) | ((df["age"] > 60) & (df["length_of_stay"] > 10)),
]
choices = ["High Risk", "Medium Risk"]
df["risk_group"] = np.select(conditions, choices, default="Low Risk")

print("\nQ12. Risk group counts:")
print(df["risk_group"].value_counts())

# Q13. Top 5 diagnoses by total bill amount, and their avg satisfaction
diag_summary = df.groupby("diagnosis").agg(
    total_bill=("bill_amount", "sum"),
    avg_satisfaction=("satisfaction_score", "mean")
).sort_values("total_bill", ascending=False)

top5_diagnoses = diag_summary.head(5)
print("\nQ13. Top 5 diagnoses by total bill amount:")
print(top5_diagnoses)
print("\nCorrelation check: compare total_bill vs avg_satisfaction above —")
print("no strong/obvious pattern usually means cost doesn't drive satisfaction directly.")


# ===========================================================
# LEVEL 5 - NUMPY DEEP DIVE
# ===========================================================
print("\n" + "=" * 60)
print("LEVEL 5 - NUMPY DEEP DIVE")
print("=" * 60)

# Q14. 95th percentile bill amount, and how many patients exceed it
p95 = np.percentile(df["bill_amount"], 95)
patients_above_p95 = (df["bill_amount"] > p95).sum()
print(f"\nQ14. 95th percentile bill amount: {p95:,.2f}")
print(f"     Patients exceeding it: {patients_above_p95}")

# Q15. Correlation between bill_amount, length_of_stay, age, satisfaction_score
corr_cols = ["bill_amount", "length_of_stay", "age", "satisfaction_score"]
corr_matrix = np.corrcoef(df[corr_cols].values, rowvar=False)
corr_df = pd.DataFrame(corr_matrix, index=corr_cols, columns=corr_cols)
print("\nQ15. Correlation matrix:")
print(corr_df.round(2))

# Q16. Z-score outlier detection on bill_amount
mean_bill = df["bill_amount"].mean()
std_bill = df["bill_amount"].std()
df["bill_zscore"] = (df["bill_amount"] - mean_bill) / std_bill

outliers = df[df["bill_zscore"].abs() > 3]  # commonly used cutoff
outlier_revenue = outliers["bill_amount"].sum()
total_revenue = df["bill_amount"].sum()

print(f"\nQ16. Outlier patients (|z-score| > 3): {len(outliers)}")
print(f"     Revenue from outliers: {outlier_revenue:,.2f}")
print(f"     Total revenue: {total_revenue:,.2f}")
print(f"     Outlier revenue share: {(outlier_revenue / total_revenue) * 100:.2f}%")


# ===========================================================
# Save cleaned data + a short summary report
# ===========================================================
df.to_csv("reports/patients_cleaned.csv", index=False)

with open("reports/summary_report.txt", "w") as f:
    f.write("HEALTHCARE ANALYSIS - SUMMARY REPORT\n")
    f.write("=" * 50 + "\n\n")
    f.write(f"Total patients: {total_patients}\n")
    f.write(f"Average bill amount: {avg_bill:,.2f}\n")
    f.write(f"Average length of stay: {avg_los:.2f} days\n")
    f.write(f"Readmission rate: {readmission_rate:.2f}%\n")
    f.write(f"Average satisfaction score: {avg_satisfaction:.2f}\n\n")
    f.write(f"Department with highest avg bill: {dept_avg_bill.idxmax()}\n")
    f.write(f"Department with most patients: {dept_count.idxmax()}\n")
    f.write(f"City with highest out-of-pocket cost: {city_oop.idxmax()}\n")
    f.write(f"Treatment with longest avg stay: {treatment_los.idxmax()}\n")
    f.write(f"Doctor with highest patient load: {top_doctor}\n")
    f.write(f"95th percentile bill amount: {p95:,.2f}\n")
    f.write(f"Outlier patients (z-score > 3): {len(outliers)}\n")
    f.write(f"Outlier revenue share: {(outlier_revenue / total_revenue) * 100:.2f}%\n")

print("\n\nDone! Cleaned data -> reports/patients_cleaned.csv")
print("Summary report -> reports/summary_report.txt")
